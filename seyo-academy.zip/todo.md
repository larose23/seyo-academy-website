# SEYO Academy Website - Project TODO

## Database & Backend
- [x] Design and implement database schema (programs, registrations, gallery, testimonials)
- [x] Set up email notification system for registrations
- [x] Create tRPC procedures for programs, registrations, gallery
- [x] Implement admin features for managing programs and registrations

## Frontend Pages
- [x] Home page with hero section, mission, programs overview, testimonials, CTAs
- [x] About Us page with mission, vision, values, team profiles, impact
- [x] Programs page with detailed program listings, age groups, pricing, schedules
- [x] Registration page with form, validation, and confirmation workflow
- [x] Gallery page with photo/video grid and lightbox
- [x] Support/Donate page with donation options and sponsorship info
- [x] Contact page with form, map, hours, contact details, social links

## Navigation & Layout
- [x] Build responsive navigation with mobile menu
- [x] Create layout wrapper with header and footer
- [ ] Implement breadcrumbs on subpages
- [x] Add smooth scrolling and page transitions

## Design & Styling
- [x] Set up color palette (athletic excellence + youth energy)
- [x] Configure typography and spacing system
- [x] Implement responsive design system
- [x] Add animations and micro-interactions
- [x] Ensure consistent branding across all pages
- [x] Improve text contrast and readability in Why Choose section

## Features & Functionality
- [x] Program registration form with validation
- [x] Automated email notifications to admins
- [x] Gallery image/video management
- [x] Testimonials section
- [x] Donation/sponsorship CTAs
- [x] Contact form with backend processing

## SEO & Performance
- [x] Add meta tags and structured data
- [ ] Optimize images and assets for production
- [x] Implement SEO best practices
- [x] Test mobile responsiveness
- [ ] Performance optimization (code splitting, lazy loading)

## Testing & QA
- [x] Write vitest tests for backend procedures
- [x] Test registration form and email notifications
- [x] Fix nested anchor tag errors in navigation and links
- [ ] Cross-browser testing
- [ ] Mobile device testing
- [ ] Accessibility audit
- [ ] Final design review and polish

## Deployment
- [x] Create checkpoint for deployment
- [ ] Deploy to production
- [ ] Verify production deployment

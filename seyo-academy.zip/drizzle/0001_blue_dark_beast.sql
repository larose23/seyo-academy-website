CREATE TABLE `contactSubmissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(20),
	`subject` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`inquiryType` enum('general','sponsorship','volunteer','partnership','other') NOT NULL,
	`status` enum('new','read','responded') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contactSubmissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `galleryItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`imageUrl` varchar(1024) NOT NULL,
	`videoUrl` varchar(1024),
	`category` enum('training','match','event','team','coaching') NOT NULL,
	`featured` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `galleryItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `programs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`ageMin` int NOT NULL,
	`ageMax` int NOT NULL,
	`skillLevel` enum('beginner','intermediate','advanced','elite') NOT NULL,
	`season` enum('fall','winter','spring','summer') NOT NULL,
	`sessionsPerWeek` int NOT NULL DEFAULT 1,
	`sessionsTotal` int NOT NULL DEFAULT 12,
	`dayOfWeek` varchar(20) NOT NULL,
	`timeStart` varchar(10) NOT NULL,
	`timeEnd` varchar(10) NOT NULL,
	`location` varchar(255) NOT NULL,
	`maxParticipants` int NOT NULL DEFAULT 30,
	`price` decimal(10,2) NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `programs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `registrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`programId` int NOT NULL,
	`parentName` varchar(255) NOT NULL,
	`parentEmail` varchar(320) NOT NULL,
	`parentPhone` varchar(20) NOT NULL,
	`childName` varchar(255) NOT NULL,
	`childAge` int NOT NULL,
	`childGender` enum('male','female','other'),
	`emergencyContactName` varchar(255),
	`emergencyContactPhone` varchar(20),
	`notes` text,
	`status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
	`paymentStatus` enum('unpaid','paid','refunded') NOT NULL DEFAULT 'unpaid',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `registrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `testimonials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`authorName` varchar(255) NOT NULL,
	`authorRole` varchar(100) NOT NULL,
	`content` text NOT NULL,
	`rating` int,
	`imageUrl` varchar(1024),
	`featured` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`isApproved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `testimonials_id` PRIMARY KEY(`id`)
);
